# Transfer Learning for White Blood Cell Classification

**Reported test accuracy:** 94.37% on 1,545 test images  
**Weighted F1-score:** 94.43%

This project uses pretrained EfficientNetB0 to classify cropped WBC microscopic images into basophil, eosinophil, lymphocyte, monocyte, and neutrophil.

## Method
- Resize images to 224 × 224
- Stratified 70%/15%/15% train/validation/test split
- Light training augmentation
- EfficientNetB0 with ImageNet pretrained weights
- Train classification head, then fine-tune final backbone layers

## Scope
This is cropped-cell classification, not object detection or WBC counting in full microscope images.

## Dataset
WBCAtt+ repository: https://github.com/apple2373/wbcattplus  
Follow its license and attribution terms. Do not upload the full dataset archive unless appropriate.

## Files
- `report/WBC_Research_Report_With_Results.docx`
- `results/classification_report.txt`
- `results/fine_tuning_accuracy.png`
- `results/fine_tuning_loss.png`

**Before submission:** add the real confusion matrix exported from Colab. It cannot be reconstructed accurately from class-level metrics alone.
